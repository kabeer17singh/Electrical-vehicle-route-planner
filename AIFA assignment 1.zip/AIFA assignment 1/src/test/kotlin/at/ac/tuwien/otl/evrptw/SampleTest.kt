package at.ac.tuwien.otl.evrptw

import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test

/**
 * <h4>About this class</h4>
 *
 * <p>Description</p>
 *
 * @author Daniel Fuevesi
 * @version 1.0.0
 * @since 1.0.0
 */
class SampleTest {

    @Test
    internal fun sampleTest() {
        Assertions.assertEquals(4, 2 + 2)
    }
}
package at.ac.tuwien.otl.evrptw.metaheuristic.neighbourhood.callable

import at.ac.tuwien.otl.evrptw.dto.EVRPTWSolution
import at.ac.tuwien.otl.evrptw.metaheuristic.neighbourhood.InterIntraRouteRelocateExplorer

class InterIntraRouteRelocateExplorerCallable(
    initialSolution: EVRPTWSolution,
    startAtIncl: Int,
    endAtIncl: Int,
    explorer: InterIntraRouteRelocateExplorer
) : INeighbourhoodExplorerCallable<EVRPTWSolution>(initialSolution, startAtIncl, endAtIncl, explorer)
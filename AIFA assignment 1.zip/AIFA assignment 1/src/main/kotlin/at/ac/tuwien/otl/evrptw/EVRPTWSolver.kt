package at.ac.tuwien.otl.evrptw

import at.ac.tuwien.otl.evrptw.construction.IConstructionHeuristic
import at.ac.tuwien.otl.evrptw.dto.EVRPTWInstance
import at.ac.tuwien.otl.evrptw.dto.EVRPTWSolution
import at.ac.tuwien.otl.evrptw.metaheuristic.IMetaHeuristic

class EVRPTWSolver {

    fun solve(instance: EVRPTWInstance, constructionHeuristic: IConstructionHeuristic, metaHeuristic: IMetaHeuristic): EVRPTWSolution {
        val solution = constructionHeuristic.generateSolution(instance)

        return metaHeuristic.improveSolution(solution)
    }
}
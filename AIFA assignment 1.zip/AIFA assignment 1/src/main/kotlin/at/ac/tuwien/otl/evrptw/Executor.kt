package at.ac.tuwien.otl.evrptw

import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


class Executor private constructor() {

    companion object {
        private var customExecutorService: ExecutorService? = null

        fun getExecutorService(): ExecutorService {
            if (customExecutorService == null) {
                customExecutorService = Executors.newFixedThreadPool(10)
            }
            return customExecutorService!!
        }
    }
}
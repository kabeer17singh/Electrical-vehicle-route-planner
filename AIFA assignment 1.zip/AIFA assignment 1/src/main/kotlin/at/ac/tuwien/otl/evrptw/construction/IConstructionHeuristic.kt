package at.ac.tuwien.otl.evrptw.construction

import at.ac.tuwien.otl.evrptw.dto.EVRPTWInstance
import at.ac.tuwien.otl.evrptw.dto.EVRPTWSolution


interface IConstructionHeuristic {

    fun generateSolution(instance: EVRPTWInstance): EVRPTWSolution
}
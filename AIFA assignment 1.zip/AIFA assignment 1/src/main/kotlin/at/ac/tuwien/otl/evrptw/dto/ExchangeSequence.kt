package at.ac.tuwien.otl.evrptw.dto


data class ExchangeSequence(
    val nodes: List<EVRPTWInstance.Node>,
    val startIndex: Int
)
package at.ac.tuwien.otl.evrptw.metaheuristic

import at.ac.tuwien.otl.evrptw.dto.EVRPTWSolution


interface IMetaHeuristic {
    fun improveSolution(evrptwSolution: EVRPTWSolution): EVRPTWSolution
}